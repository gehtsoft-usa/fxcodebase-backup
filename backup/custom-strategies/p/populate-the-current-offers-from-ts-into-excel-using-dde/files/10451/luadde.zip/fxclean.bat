@echo off


@echo ************************************************************************
@echo ---------------Start Cleaning  Lua VM.--------------------
@if exist bin\*.*   del bin\*.* /f /q /s
@if exist bin       rmdir bin /q /s
@if exist lib\*.*   del lib\*.* /f /q /s
@if exist lib       rmdir lib /q /s
@if exist obj\*.*   del obj\*.* /f /q /s
@if exist obj       rmdir obj /q /s
@if exist *.dl*                                         del *.dl* /f /q /s
@if exist *.lib                                         del *.lib /f /q /s
@if exist *.err                                         del *.err /f /q /s
@if exist test\ddeserver_lua.dll del test\ddeserver_lua.dll
@if exist test\luaint.exe del test\luaint.exe
@if exist test\ddeserver_lua.exe del test\ddeserver_lua.exe
@if exist test\lua5.1.dll del test\lua5.1.dll
@if exist test\lua5.1.std.dll del test\lua5.1.std.dll
@if exist test\lua5.1.jit.dll del test\lua5.1.jit.dll
@echo ---------------Finished cleaning Lua VM.-----------------
@echo ************************************************************************
