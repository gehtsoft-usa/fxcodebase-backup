class DdeServerValue
{
 public:
    DdeServerValue(DWORD idInst, const char *name);
    ~DdeServerValue();

    bool CompareName(HSZ name);
    HSZ GetName();
    void SetValue(double value);
    void SetValue(const char *value);
    unsigned _int8 *GetText(unsigned int *length);
    unsigned _int8 *GetExcel(unsigned int *size);
 private:
    DWORD mIdInst;                  //instance handle
    HSZ mName;                      //name of the value
    std::string mRawName;           //raw name
    std::string mText;              //text value
    unsigned int mExcelSize;        //size of the excel data
    unsigned _int8 *mExcelData;     //excel value
};

class DdeServerTopic
{
 public:
    DdeServerTopic(DWORD idInst, const char *name);
    ~DdeServerTopic();
    HSZ GetName();
    bool CompareName(HSZ name);
    int AddValue(const char *name);
    DdeServerValue *GetValue(HSZ name);
    DdeServerValue *GetValue(int index);
 private:
    DWORD mIdInst;                          //instance handle
    HSZ mName;                              //name of the topic
    std::string mRawName;           //raw name
    std::vector<DdeServerValue *> mValues;  //the list of the values
};


class DdeServer
{
 public:
    DdeServer(const char *name);
    ~DdeServer();

    bool CompareName(HSZ name);
    int AddTopic(const char *name);
    DdeServerTopic *GetTopic(HSZ name);
    int AddValue(int topic, const char *name);
    void SetValue(int topic, int vindex, double value);
    void SetValue(int topic, int vindex, const char *value);
    void Quit();
 private:
    static void _cdecl DdeServerProc(void *lpv);
    static HDDEDATA EXPENTRY DdeCallback(UINT wType, UINT fmt, HCONV hConv, HSZ hsz1, HSZ hsz2, HDDEDATA hData, DWORD dwData1, DWORD dwData2);

    DWORD mThreadId;
    DWORD mIdInst;
    HSZ mName;
    std::string mRawName;
    volatile bool mStarted;
    std::vector<DdeServerTopic *> mTopics;
    volatile bool mQuitRequest;
    volatile bool mQuited;
    HANDLE mMutex;
};
