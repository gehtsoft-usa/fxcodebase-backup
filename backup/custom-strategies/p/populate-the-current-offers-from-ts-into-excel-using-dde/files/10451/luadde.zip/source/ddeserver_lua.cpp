#include "stdafx.h"
#include "strings.h"
#include "ddeserver_lua.h"
#include "ddeserver.h"

HINSTANCE gInst;
DWORD gTlsIndex;
UINT XL_TABLE;

DdeServer *lua_get_DdeServer(lua_State *L, int index)
{
    if (lua_istable(L, index) == 0)
        return 0;
    lua_pushstring(L, "__raw_DdeServer");
    lua_rawget(L, index);

    if (lua_isuserdata(L, -1) == 0)
    {
        lua_pop(L, 1);
        return 0;
    }
    DdeServer* info = *(DdeServer**)lua_touserdata(L, -1);
    lua_pop(L, 1);
    return info;
}

int lua_server_gc(lua_State *L)
{
    DdeServer* info = *(DdeServer**)lua_touserdata(L, 1);
    if (info != 0)
    {
        info->Quit();
        delete info;
    }
    return 0;
}

int lua_server_close(lua_State *L)
{
    DdeServer *info = lua_get_DdeServer(L, 1);
    if (info == 0)
        return luaL_error(L, Strings::ObjectBroken());
    info->Quit();
    return 1;
}

int lua_server_set(lua_State *L)
{
    DdeServer *info = lua_get_DdeServer(L, 1);
    if (info == 0)
        return luaL_error(L, Strings::ObjectBroken());

    if (lua_isnumber(L, 2) == 0)
        return luaL_error(L, Strings::FirstParameterNumber());
    if (lua_isnumber(L, 3) == 0)
        return luaL_error(L, Strings::SecondParameterNumber());
    if (lua_isnumber(L, 4) == 0 && lua_isstring(L, 4) == 0)
        return luaL_error(L, Strings::ThirdParameterStringOrNumber());

    if (lua_isnumber(L, 4))
        info->SetValue((int)lua_tonumber(L, 2), (int)lua_tonumber(L, 3), lua_tonumber(L, 4));
    else
        info->SetValue((int)lua_tonumber(L, 2), (int)lua_tonumber(L, 3), lua_tostring(L, 4));

    return 0;
}

int lua_server_addTopic(lua_State *L)
{
    DdeServer *info = lua_get_DdeServer(L, 1);
    if (info == 0)
        return luaL_error(L, Strings::ObjectBroken());

    if (lua_isstring(L, 2) == 0)
        return luaL_error(L, Strings::FirstParameterNumber());

    lua_pushinteger(L, info->AddTopic(lua_tostring(L, 2)));
    return 1;
}

int lua_server_addValue(lua_State *L)
{
    DdeServer *info = lua_get_DdeServer(L, 1);
    if (info == 0)
        return luaL_error(L, Strings::ObjectBroken());

    if (lua_isnumber(L, 2) == 0)
        return luaL_error(L, Strings::FirstParameterNumber());
    if (lua_isstring(L, 3) == 0)
        return luaL_error(L, Strings::SecondParameterString());

    lua_pushinteger(L, info->AddValue((int)lua_tonumber(L, 2), lua_tostring(L, 3)));
    return 1;
}


void lua_push_server(lua_State *L, DdeServer *info)
{
    lua_newtable(L);

    lua_newuserdata(L, sizeof(DdeServer *));
    *(DdeServer **)(lua_touserdata(L, -1)) = info;
    if (luaL_newmetatable(L, "_dde_serverdata_metatablegc") != 0)
    {
        lua_pushcfunction(L, lua_server_gc);
        lua_setfield(L, -2, "__gc");
    }
    lua_setmetatable(L, -2);
    lua_setfield(L, -2, "__raw_DdeServer");

    lua_pushcfunction(L, lua_server_close);
    lua_setfield(L, -2, "close");
    lua_pushcfunction(L, lua_server_set);
    lua_setfield(L, -2, "set");
    lua_pushcfunction(L, lua_server_addTopic);
    lua_setfield(L, -2, "addTopic");
    lua_pushcfunction(L, lua_server_addValue);
    lua_setfield(L, -2, "addValue");
}

int ll_new(lua_State *L)
{
    if (lua_isstring(L, 1) == 0)
        return luaL_error(L, Strings::FirstParameterString());
printf("%s\n", lua_tostring(L, 1));
    DdeServer *info = new DdeServer(lua_tostring(L, 1));

    lua_push_server(L, info);
    return 1;
}


static const struct luaL_reg unicode_lua_lib [] =
{
     {"new", ll_new},
     {NULL, NULL}
};

extern "C" __declspec(dllexport) int luaopen_ddeserver_lua (lua_State *L)
{
    luaL_register(L, "ddeserver_lua", unicode_lua_lib);

    lua_getglobal(L, "ddeserver_lua");
    if (lua_isnil(L, -1) || !lua_istable(L, -1)) {
        luaL_error(L, Strings::IsNotRegistered());
    }
    return 1;
}

BOOL APIENTRY DllMain(HANDLE hModule, DWORD dwReason, LPVOID lpReserved)
{
    if (dwReason == DLL_PROCESS_ATTACH)
    {
        gTlsIndex = TlsAlloc();
        gInst = (HINSTANCE)hModule;
        XL_TABLE = RegisterClipboardFormat((LPSTR)"XlTable");
    }
    else if (dwReason == DLL_PROCESS_DETACH)
    {
        if (gTlsIndex != TLS_OUT_OF_INDEXES)
            TlsFree(gTlsIndex);
    }
    return TRUE;
}

