class Strings
{
 public:
    static const char *FirstParameterString();
    static const char *FirstParameterNumber();
    static const char *SecondParameterString();
    static const char *SecondParameterNumber();
    static const char *ThirdParameterStringOrNumber();
    static const char *CantCreateProcess();
    static const char *CantConnect();
    static const char *CantInitDde();
    static const char *IsNotRegistered();
    static const char *ObjectBroken();
};
