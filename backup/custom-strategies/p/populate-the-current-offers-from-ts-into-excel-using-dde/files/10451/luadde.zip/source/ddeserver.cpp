#include "stdafx.h"
#include "ddeserver.h"


extern DWORD gTlsIndex;
extern UINT XL_TABLE;

#define WM_USER_POSTADVICE WM_USER + 0x100

DdeServerValue::DdeServerValue(DWORD idInst, const char *name)
{
    mIdInst = idInst;
    mRawName = name;
    mName = 0;
    mExcelData = 0;
    SetValue((const char *)0);
}

HSZ DdeServerValue::GetName()
{
    return mName;
}

DdeServerValue::~DdeServerValue()
{
    if (mExcelData != 0)
        delete[] mExcelData;
    DdeFreeStringHandle(mIdInst, mName);
}

bool DdeServerValue::CompareName(HSZ name)
{
    if (mName == 0)
        mName = DdeCreateStringHandle(mIdInst, mRawName.c_str(), CP_WINANSI);
    return DdeCmpStringHandles(name, mName) == 0;
}

void DdeServerValue::SetValue(double value)
{
    char buff[256];
    sprintf_s(buff, 256, "%f", value);
    mText = buff;
    
    if (mExcelData != 0)
        delete[] mExcelData;

    mExcelSize = 8 + 4 + sizeof(double);
    mExcelData = new unsigned _int8[mExcelSize];
    *(short *)(mExcelData + 0) = 0x0010;                              // tdtTable
    *(short *)(mExcelData + 2) = 4;                                   // 2 shorts followed
    *(short *)(mExcelData + 4) = 1;                                   // 1 row
    *(short *)(mExcelData + 6) = 1;                                   // 1 column
    *(short *)(mExcelData + 8) = 0x0001;                              // tdtFloat
    *(short *)(mExcelData + 10) = sizeof(double);                     // float value size
    *(double *)(mExcelData + 12) = value;

}

void DdeServerValue::SetValue(const char *value)
{
    if (value == 0)
        value = "";
    mText = value;

    if (mExcelData != 0)
        delete[] mExcelData;

    int mExcelSize1 = (int)strlen(value);
    if (mExcelSize1 > 254)
        mExcelSize1 = 254;

    mExcelSize = 8 + 4 + mExcelSize1 + 1;
    mExcelData = new unsigned _int8[mExcelSize];
    *(short *)(mExcelData + 0) = 0x0010;                                    // tdtTable
    *(short *)(mExcelData + 2) = 4;                                         // 2 shorts followed
    *(short *)(mExcelData + 4) = 1;                                         // 1 row
    *(short *)(mExcelData + 6) = 1;                                         // 1 column
    *(short *)(mExcelData + 8) = 0x0002;                                    // tdtString
    *(short *)(mExcelData + 10) = mExcelSize1 + 1;                          // string and its mExcelSize followed
    *(unsigned char *)(mExcelData + 12) = (unsigned char)(mExcelSize1);     // string
    if (mExcelSize1 != 0)
        memcpy_s(mExcelData + 13, mExcelSize, value, mExcelSize1);          // copy string content
}

unsigned _int8 *DdeServerValue::GetText(unsigned int *length)
{
    *length = (unsigned int)mText.length();
    return (unsigned _int8 *)mText.c_str();
}

unsigned _int8 * DdeServerValue::GetExcel(unsigned int *size)
{
    *size = mExcelSize;
    return mExcelData;
}

DdeServerTopic::DdeServerTopic(DWORD idInst, const char *name)
{
    mIdInst = idInst;
    mRawName = name;
    mName = 0;
}

DdeServerTopic::~DdeServerTopic()
{
    for (unsigned int i = 0; i < mValues.size(); i++)
        delete mValues[i];
    mValues.clear();
    DdeFreeStringHandle(mIdInst, mName);
}


bool DdeServerTopic::CompareName(HSZ name)
{
    if (mName == 0)
        mName = DdeCreateStringHandle(mIdInst, mRawName.c_str(), CP_WINANSI);
    return DdeCmpStringHandles(name, mName) == 0;
}

int DdeServerTopic::AddValue(const char *name)
{
    mValues.push_back(new DdeServerValue(mIdInst, name));
    return (int)(mValues.size() - 1);
}

DdeServerValue *DdeServerTopic::GetValue(HSZ name)
{
    for (unsigned int i = 0; i < mValues.size(); i++)
        if (mValues[i]->CompareName(name))
            return mValues[i];

    return 0;
}

HSZ DdeServerTopic::GetName()
{
    return mName;
}


DdeServerValue *DdeServerTopic::GetValue(int index)
{
    if (index >= 0 && index < (int)mValues.size())
        return mValues[index];
    else
        return 0;
}

DdeServer::DdeServer(const char *name)
{
    mIdInst = 0;
    mRawName = name;
    mQuitRequest = mQuited = false;
    mStarted = false;
    mMutex = CreateMutex(0, FALSE, 0);
    _beginthread(DdeServerProc, 0, (void *)this);
    Sleep (50);
    while (!mStarted);
}

DdeServer::~DdeServer()
{
    if (!mQuited)
        Quit();
    CloseHandle(mMutex);
}


bool DdeServer::CompareName(HSZ name)
{
    if (mIdInst == 0)
        return false;
    return DdeCmpStringHandles(name, mName) == 0;
}

int DdeServer::AddTopic(const char *name)
{
    if (mIdInst == 0)
        return -1;
    if (WaitForSingleObject(mMutex, INFINITE) == WAIT_OBJECT_0)
    {
        mTopics.push_back(new DdeServerTopic(mIdInst, name));
        int rc = (int)(mTopics.size() - 1);
        ReleaseMutex(mMutex);
        return rc;
    }
    else
        return -1;
}

int DdeServer::AddValue(int topic, const char *name)
{
    if (mIdInst == 0)
        return -1;
    if (WaitForSingleObject(mMutex, INFINITE) == WAIT_OBJECT_0)
    {
        int rc = -1;
        if (topic >= 0 && topic < ((int)mTopics.size()))
            rc = mTopics[topic]->AddValue(name);
        ReleaseMutex(mMutex);
        return rc;
    }
    else
        return -1;
}

void DdeServer::SetValue(int topic, int vindex, double value)
{
    if (mIdInst == 0)
        return ;
    if (WaitForSingleObject(mMutex, INFINITE) == WAIT_OBJECT_0)
    {
        DdeServerTopic *dt = 0;
        DdeServerValue *dv = 0;
        if (topic >= 0 && topic < ((int)mTopics.size()))
            dt = mTopics[topic];
        if (dt != 0)
            dv = dt->GetValue(vindex);
        if (dv != 0)
        {
            dv->SetValue(value);
            PostThreadMessage(mThreadId, WM_USER_POSTADVICE, (WPARAM)topic, (LPARAM)vindex);
        }
        ReleaseMutex(mMutex);
    }
}

void DdeServer::SetValue(int topic, int vindex, const char *value)
{
    if (mIdInst == 0)
        return ;
    if (WaitForSingleObject(mMutex, INFINITE) == WAIT_OBJECT_0)
    {
        DdeServerTopic *dt = 0;
        DdeServerValue *dv = 0;
        if (topic >= 0 && topic < ((int)mTopics.size()))
            dt = mTopics[topic];
        if (dt != 0)
            dv = dt->GetValue(vindex);
        if (dv != 0)
        {
            dv->SetValue(value);
            PostThreadMessage(mThreadId, WM_USER_POSTADVICE, (WPARAM)topic, (LPARAM)vindex);
        }
        ReleaseMutex(mMutex);
    }
}

void DdeServer::Quit()
{
    mQuitRequest = true;
    while (!mQuited);
    return;
}

void _cdecl DdeServer::DdeServerProc(void *lpv)
{
    DdeServer *server = (DdeServer *)lpv;
    TlsSetValue(gTlsIndex, lpv);
    server->mThreadId = GetCurrentThreadId();
    DdeInitialize(&server->mIdInst, DdeServer::DdeCallback, APPCLASS_STANDARD, 0);
    server->mName = DdeCreateStringHandle(server->mIdInst, server->mRawName.c_str(), CP_WINANSI);
    DdeNameService(server->mIdInst, server->mName, NULL, DNS_REGISTER);

    server->mStarted = true;
    MSG msg;
    while (true)
    {
        while (PeekMessage(&msg, 0, 0, 0, PM_REMOVE))
        {
            if (msg.message == WM_USER_POSTADVICE)
            {
                int topic = (int)msg.wParam;
                int vindex = (int)msg.lParam;
                DdeServerTopic *dt = 0;
                DdeServerValue *dv = 0;
                if (topic >= 0 && topic < ((int)server->mTopics.size()))
                    dt = server->mTopics[topic];
                if (dt != 0)
                    dv = dt->GetValue(vindex);
                if (dv != 0)
                    DdePostAdvise(server->mIdInst, dt->GetName(), dv->GetName());
            }
            else
            {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
        }

        if (server->mQuitRequest)
            break;
        else
            Sleep(50);
    }

    for (unsigned int i = 0; i < server->mTopics.size(); i++)
        delete server->mTopics[i];
    server->mTopics.clear();
    DdeFreeStringHandle(server->mIdInst, server->mName);
    DdeUninitialize(server->mIdInst);
    server->mIdInst = 0;
    server->mQuited = true;
    return ;
}

DdeServerTopic *DdeServer::GetTopic(HSZ name)
{
    for (unsigned int i = 0; i < mTopics.size(); i++)
        if (mTopics[i]->CompareName(name))
            return mTopics[i];
    return 0;
}

HDDEDATA EXPENTRY DdeServer::DdeCallback(UINT wType, UINT fmt, HCONV hConv, HSZ hsz1, HSZ hsz2, HDDEDATA hData, DWORD dwData1, DWORD dwData2)
{
    DdeServer *server = (DdeServer *)TlsGetValue(gTlsIndex);
    HDDEDATA rc = (HDDEDATA)0;
    if (server != 0)
    {
        if (WaitForSingleObject(server->mMutex, INFINITE) == WAIT_OBJECT_0)
        {
            switch (wType)
            {
            case    XTYP_CONNECT:
                    {
                        if (server->CompareName(hsz2) && server->GetTopic(hsz1) != 0)
                            rc = (HDDEDATA)TRUE;
                    }
                    break;
            case    XTYP_ADVSTART:
                    {
                        DdeServerTopic *topic = 0;
                        DdeServerValue *value = 0;

                        topic = server->GetTopic(hsz1);

                        if (topic)
                            value = topic->GetValue(hsz2);

                        if (value)
                            rc = (HDDEDATA)TRUE;
                    }
                    break;
            case    XTYP_ADVREQ:
            case    XTYP_REQUEST:
                    {
                        DdeServerTopic *topic = 0;
                        DdeServerValue *value = 0;

                        topic = server->GetTopic(hsz1);

                        if (topic)
                            value = topic->GetValue(hsz2);

                        if (value)
                        {
                            const unsigned _int8 *data = 0;
                            unsigned int length;
                            if (fmt == CF_TEXT)
                                data = value->GetText(&length);
                            else if (fmt == XL_TABLE)
                                data = value->GetExcel(&length);

                            if (data != 0)
                                rc = DdeCreateDataHandle(server->mIdInst, (UCHAR*)data, length, 0, hsz2, fmt, 0);
                        }
                    }
                    break;
            }
            ReleaseMutex(server->mMutex);
        }
    }

    return rc;
}




