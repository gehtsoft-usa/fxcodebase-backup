#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <direct.h>
#include <string>
#include <vector>
#include <process.h>

#define LUA_BUILD_AS_DLL
#define LUA_LIB

#include "../../../../lua/include/lua_all.h"
