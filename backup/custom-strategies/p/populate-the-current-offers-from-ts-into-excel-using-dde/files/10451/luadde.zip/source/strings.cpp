#include "stdafx.h"
#include "strings.h"

const char *Strings::FirstParameterString()
{
    return "The first parameter must be a string";
}

const char *Strings::FirstParameterNumber()
{
    return "The first parameter must be a number";
}

const char *Strings::SecondParameterString()
{
    return "The second parameter must be a string";
}

const char *Strings::SecondParameterNumber()
{
    return "The second parameter must be a string";
}

const char *Strings::ThirdParameterStringOrNumber()
{
    return "The third parameter must be a string or a number";
}

const char *Strings::IsNotRegistered()
{
    return "Module ddeserver_lua isn't  registered";
}

const char *Strings::ObjectBroken()
{
    return "Object is broken or . is used instead of :";
}

const char *Strings::CantCreateProcess()
{
    return "Can't create the process";
}

const char *Strings::CantConnect()
{
    return "Can't connect to the DDE service";
}

const char *Strings::CantInitDde()
{
    return "Can't initialize the DDE service";
}



