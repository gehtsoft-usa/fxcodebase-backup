-- Indicator profile initialization routine
-- Defines indicator profile properties and indicator parameters
-- TODO: Add minimal and maximal value of numeric parameters and default color of the streams
function Init()
    indicator:name("Pipe Client");
    indicator:description("InterOp");
    indicator:requiredSource(core.Bar);
    indicator:type(core.Indicator);

    indicator.parameters:addString("Magic", "Magic String", "No description", "MyID");
    indicator.parameters:addColor("S1_color", "Color of S1", "Color of S1", core.rgb(255, 0, 0));
end

-- Indicator instance initialization routine
-- Processes indicator parameters and creates output streams
-- TODO: Refine the first period calculation for each of the output streams.
-- TODO: Calculate all constants, create instances all subsequent indicators and load all required libraries
-- Parameters block
local Magic;

local first;
local source = nil;

-- Streams block
local S1 = nil;
local fonts;
-- Strategy
local isStrategyStarted = false;
local my_Strategy = nil;

-- Routine
function Prepare(nameOnly)
    Magic = instance.parameters.Magic;
    source = instance.source;
    first = source:first();

    local name = profile:id() .. "(" .. source:name() .. ", " .. tostring(Magic) .. ")";
    instance:name(name);

    if (not (nameOnly)) then
        S1 = instance:addStream("S1", core.Line, name, "S1", instance.parameters.S1_color, first);
		fonts		= core.host:execute("createFont","Consolas",9,false,false);
    end
end
---------------------------------------------------------------------------------------------------------------------------------
-- ReleaseInstance --------------------------------------------------------------------------------------------------------------
function ReleaseInstance()
		_G = nil;
	   core.host:execute("deleteFont", fonts);
end
-- Indicator calculation routine
-- TODO: Add your code for calculation output values
function Update(period)
    if period >= first and source:hasData(period) then
        -- Check Strategy Status 
		if not isStrategyStarted then
			-- Strategy is not running, so wait until it is.
			local i, n;
			my_Strategy = nil;
			--Search for the Pipe Server
			for i = 0, interop:size() - 1, 1 do
				n = interop:instance(i);
				if n:name() == "PIPE_SERVER" .. "(" .. Magic .. ")" and interop:isalive(n) then
					my_Strategy = n;
					sendStatus("OK - Strategy is running");
					isStrategyStarted = true;
					return ;
				end
			end
			if my_Strategy ==  nil then
				-- Didn't find the 
				sendStatus("Upps - Strategy is not running - Check if Strategy is running and Magic String match");
			end
		else
			-- Strategy is running
			-- Check if Strategy is Still Running
			if interop:isalive(my_Strategy) then
				sendStatus("OK - Strategy is running");
				-- Pipe Server is running so send your request here
				---------------------------------------------------
				local price = my_Strategy:invoke("getPrice");
				dText(string.format("Price received from Pipe Server = %.5f",price),1000,5,50,instance.parameters.S1_color,fonts);
			else
				sendStatus("Upps is no longer running - Trading will not possible");
				isStrategyStarted = false;
			end
		end
    end
end
---------------------------------------------------------------------------------------------------------------------------------
-- Send Status ------------------------------------------------------------------------------------------------------------------
function sendStatus(txt)
    core.host:execute ("setStatus", txt);
end
-- Drawing Text called to draw all Labels ---------------------------------------------------------------------------------------
function dText(text,ID,x,y,color,f)
	core.host:execute(	"drawLabel1", ID, x, core.CR_LEFT, y, core.CR_TOP, core.H_Right, core.V_Bottom,
							f, color, text);
end