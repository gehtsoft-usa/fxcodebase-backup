struct JMA;

struct JMA *AllocJMA();
void FreeJMA(struct JMA *jma);
/** Initializes struct JMA structure for further calculations. */
void JJMAInit(struct JMA *jma);
/** Updates struct JMA's coefficients depending on the phase and length parameters. */
void JJMAUpdateCoefficients(struct JMA *jma, int a_Phase, int a_Length);
/** Stores struct JMA calculation context in order to restart calculation from the same period. */
void JJMAStoreContext(struct JMA *jma, struct JMA *jma1);
/** Restores struct JMA calculation context. */
void JJMARestoreContext(struct JMA *jma, struct JMA *jma1);
/** Calculate the next struct JMA value in a row. */
double JJMASeries(struct JMA *jma, double a_current);





