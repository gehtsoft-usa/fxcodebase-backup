#include "stdafx.h"
#include "jma.h"
#define INDICORE2_EXTKIT
#include "C:/Gehtsoft/IndicoreDev/include/indicore2.h"
#include "jmalua.h"
#include "jrxlua.h"

int lua_jma(lua_State *L)
{
    lua_jma_push(L);
    return 1;
}

int lua_jrx(lua_State *L)
{
    lua_jrx_push(L);
    return 1;
}

static const struct luaL_reg jmalua_lib [] =
{
     {"jma", lua_jma},
     {"jrx", lua_jrx},
     {NULL, NULL}
};

extern "C" int __declspec(dllexport) luaopen_jmalua (lua_State *L)
{
    luaL_register(L, "jmalua", jmalua_lib);

    lua_getglobal(L, "jmalua");
    if (lua_isnil(L, -1) || !lua_istable(L, -1))
    {
        luaL_error(L, "the jmalua library is not registered");
    }
    return 1;
}
