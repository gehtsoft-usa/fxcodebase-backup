#include "stdafx.h"
#include "jma.h"
#include <math.h>
//#define INDICORE2_EXTKIT
//#include "C:/Gehtsoft/IndicoreDev/include/indicore2.h"

/** JMA structure. */
struct JMA
{
    double f18, f38, fA8, fC0, fC8, s8, s18, v1, v2;
    double v3, f90, f78, f88, f98, vJMA, list[128], ring1[128];
    double ring2[11], buffer[62]; 
    double Kg, Pf;
    int    s28, s30, s38, s40, s48, f0, s50, s70, LP2;
    int    LP1;
    double fA0, vv, v4, f70, s20, s10, fB0, fD0, f8, f60, f20, f28;
    double f30, f40, f48, f58, f68;
    int    v5, v6, fE0, fD8, fE8, val, s58, s60, s68, size;
    int    m;
};

struct JMA *AllocJMA()
{
    return new JMA;
}

void FreeJMA(struct JMA *jma)
{
    delete jma;
}

/** Initializes JMA structure for further calculations. */
void JJMAInit(struct JMA *jma)
{
    jma->f18 = 0;
    jma->f38 = 0;
    jma->fA8 = 0;
    jma->fC0 = 0;
    jma->fC8 = 0;
    jma->s8 = 0;
    jma->s18 = 0;
    jma->v1 = 0;
    jma->v2 = 0;
    jma->v3 = 0;
    jma->f90 = 0;
    jma->f78 = 0;
    jma->f88 = 0;
    jma->f98 = 0;
    jma->vJMA = 0;
    jma->Kg = 0;
    jma->Pf = 0;
    jma->s38 = 0;
    jma->s40 = 0;
    jma->s48 = 0;
    jma->s50 = 0;
    jma->s70 = 0;
    jma->LP2 = 0;
    jma->LP1 = 0;
    jma->fA0 = 0;
    jma->vv = 0;
    jma->v4 = 0;
    jma->f70 = 0;
    jma->s20 = 0;
    jma->s10 = 0;
    jma->fB0 = 0;
    jma->fD0 = 0;
    jma->f8 = 0;
    jma->f60 = 0;
    jma->f20 = 0;
    jma->f28 = 0;
    jma->f30 = 0;
    jma->f40 = 0;
    jma->f48 = 0;
    jma->f58 = 0;
    jma->f68 = 0;
    jma->v5 = 0;
    jma->v6 = 0;
    jma->fE0 = 0;
    jma->fD8 = 0;
    jma->fE8 = 0;
    jma->val = 0;
    jma->s58 = 0;
    jma->s60 = 0;
    jma->s68 = 0;
    jma->size = 0;
    jma->m = 0;

    int i;

    for (i = 0; i < 128; i++)
    {
        jma->ring1[i] = 0;
    }

    for (i = 0; i < 11; i++)
    {
        jma->ring2[i] = 0;
    }

    for (i = 0; i < 62; i++)
        jma->buffer[i] = 0;

    jma->f0 = 1;
    jma->s28 = 63;
    jma->s30 = 64;

    for(i = 0; i <= jma->s28; i++)
        jma->list[i] = -1000000.0;

    for (i = jma->s30; i <= 127; i++)
        jma->list[i] = 1000000.0;
}

/** Updates JMA's coefficients depending on the phase and length parameters. */
void JJMAUpdateCoefficients(struct JMA *jma, int a_Phase, int a_Length)
{
    //calculate coefficients
    double Dr, Ds, Dl;
    if(a_Length < 1.0000000002)
        Dr = 0.0000000001;
    else
        Dr = (a_Length - 1.0) / 2.0;
    if ((a_Phase >= -100) && (a_Phase <= 100))
        jma->Pf = a_Phase / 100.0 + 1.5;
    if (a_Phase > 100)
        jma->Pf = 2.5;
    if (a_Phase < -100)
        jma->Pf = 0.5;
    Dr = Dr * 0.9;
    jma->Kg = Dr / (Dr + 2.0);
    Ds = sqrt(Dr);
    Dl = log(Ds);
    jma->v1 = Dl;
    jma->v2 = jma->v1;
    if ((jma->v1 / log(2.0)) + 2.0 < 0.0)
        jma->v3 = 0.0;
    else
        jma->v3 = (jma->v2 / log(2.0)) + 2.0;
    jma->f98= jma->v3;
    if (jma->f98 >= 2.5)
        jma->f88 = jma->f98 - 2.0;
    else
        jma->f88 = 0.5;
    jma->f78 = Ds * jma->f98;
    jma->f90 = jma->f78 / (jma->f78 + 1.0);
}

/** Restores JMA calculation context. */
void JJMARestoreContext(struct JMA *jma, struct JMA *jma1)
{
    memcpy(jma, jma1, sizeof(struct JMA));
}

/** Stores JMA calculation context in order to restart calculation from the same period. */
void JJMAStoreContext(struct JMA *jma, struct JMA *jma1)
{
    memcpy(jma1, jma, sizeof(struct JMA));
}

/** Calculate the next JMA value in a row. */
double JJMASeries(struct JMA *jma, double a_current)
{
    int i, j;

    if (jma->LP1 < 61)
    {
        jma->LP1++;
        jma->buffer[jma->LP1] = a_current;
    }

    if (jma->LP1 > 30)
    {
        if (jma->f0 != 0)
        {
            jma->f0 = 0;
            jma->v5 = 1;
            jma->fD8 = jma->v5 * 30;
            if (jma->fD8 == 0)
                jma->f38 = a_current;
            else
                jma->f38 = jma->buffer[1];
            jma->f18 = jma->f38;
            if (jma->fD8 > 29)
                jma->fD8 = 29;
        }
        else
            jma->fD8 = 0;

        for(i = jma->fD8; i >= 0; i--)
        {
            jma->val = 31 - i;
            if (i == 0)
                jma->f8 = a_current;
            else
                jma->f8 = jma->buffer[jma->val];
            jma->f28 = jma->f8 - jma->f18;
            jma->f48 = jma->f8 - jma->f38;
            if (fabs(jma->f28) > fabs(jma->f48))
                jma->v2 = fabs(jma->f28);
            else
                jma->v2 = fabs(jma->f48);
            jma->fA0 = jma->v2;
            jma->vv = jma->fA0 + 0.0000000001; //{1.0e-10;}
            if (jma->s48 <= 1)
                jma->s48 = 127;
            else
                jma->s48 = jma->s48 - 1;
            if (jma->s50 <= 1)
                jma->s50 = 10;
            else
                jma->s50 = jma->s50 - 1;
            if (jma->s70 < 128)
                jma->s70 = jma->s70 + 1;
            jma->s8 = jma->s8 + jma->vv - jma->ring2[jma->s50];
            jma->ring2[jma->s50] = jma->vv;
            if (jma->s70 > 10)
                jma->s20 = jma->s8 / 10.0;
            else
                jma->s20 = jma->s8 / jma->s70;

            if (jma->s70 > 127)
            {
                jma->s10 = jma->ring1[jma->s48];
                jma->ring1[jma->s48] = jma->s20;
                jma->s68 = 64;
                jma->s58 = jma->s68;
                while (jma->s68 > 1)
                {
                    if (jma->list[jma->s58] < jma->s10)
                    {
                        jma->s68 = jma->s68 * 0.5;
                        jma->s58 = jma->s58 + jma->s68;
                    }
                    else
                    {
                        if (jma->list[jma->s58]<= jma->s10)
                            jma->s68 = 1;
                        else
                        {
                            jma->s68 = jma->s68 * 0.5;
                            jma->s58 = jma->s58 - jma->s68;
                        }
                    }
                }

            }
            else
            {
                jma->ring1[jma->s48] = jma->s20;
                if (jma->s28 + jma->s30 > 127)
                {
                    jma->s30 = jma->s30 - 1;
                    jma->s58 = jma->s30;
                }
                else
                {
                    jma->s28 = jma->s28 + 1;
                    jma->s58 = jma->s28;
                }
                if (jma->s28 > 96)
                    jma->s38 = 96;
                else
                    jma->s38 = jma->s28;
                if (jma->s30 < 32)
                    jma->s40 = 32;
                else
                    jma->s40 = jma->s30;
            }
            jma->s68 = 64;
            jma->s60 = jma->s68;

            while (jma->s68 > 1)
            {
                if (jma->list[jma->s60] >= jma->s20)
                {
                    if (jma->list[jma->s60 - 1] <= jma->s20)
                        jma->s68 = 1;
                    else
                    {
                        jma->s68 = jma->s68 * 0.5;
                        jma->s60 = jma->s60 - jma->s68;
                    }
                }
                else
                {
                    jma->s68 = jma->s68 * 0.5;
                    jma->s60 = jma->s60 + jma->s68;
                }
                if ((jma->s60 == 127) && (jma->s20 > jma->list[127]))
                    jma->s60 = 128;
            }

            if (jma->s70 > 127)
            {
                if (jma->s58 >= jma->s60)
                {
                    if ((jma->s38 + 1 > jma->s60) && (jma->s40 - 1 < jma->s60))
                        jma->s18 = jma->s18 + jma->s20;
                    else if ((jma->s40 + 0 > jma->s60) && (jma->s40 - 1 < jma->s58))
                            jma->s18 = jma->s18 + jma->list[jma->s40 - 1];
                }
                else if (jma->s40 >= jma->s60)
                {
                    if ((jma->s38 + 1 < jma->s60) && (jma->s38 + 1 > jma->s58))
                        jma->s18 = jma->s18 + jma->list[jma->s38 + 1]; }
                    else if  (jma->s38 + 2 > jma->s60)
                        jma->s18 = jma->s18 + jma->s20;
                    else if ((jma->s38 + 1 < jma->s60) && (jma->s38 + 1 > jma->s58))
                        jma->s18 = jma->s18 + jma->list[jma->s38 + 1];

                    if (jma->s58 > jma->s60)
                    {
                        if ((jma->s40 - 1 < jma->s58) && (jma->s38 + 1 > jma->s58))
                            jma->s18 = jma->s18 - jma->list[jma->s58];
                        else
                        if ((jma->s38 < jma->s58) && (jma->s38 + 1 > jma->s60))
                            jma->s18 = jma->s18 - jma->list[jma->s38];
                    }
                    else
                    {
                        if ((jma->s38 + 1 > jma->s58) && (jma->s40 - 1 < jma->s58))
                            jma->s18 = jma->s18 - jma->list[jma->s58];
                        else
                        if ((jma->s40 + 0 > jma->s58) && (jma->s40 - 0 < jma->s60))
                            jma->s18 = jma->s18 - jma->list[jma->s40];
                    }
            }

            if (jma->s58 <= jma->s60)
            {
                if (jma->s58 >= jma->s60)
                {
                    jma->list[jma->s60] = jma->s20;
                }
                else
                {
                    for( j = jma->s58 + 1; j<=jma->s60 - 1 ;j++)
                        jma->list[j - 1] = jma->list[j];
                    jma->list[jma->s60 - 1] = jma->s20;
                }
            }
            else
            {
                for(j = jma->s58 - 1; j>=jma->s60 ;j--)
                    jma->list[j + 1] = jma->list[j];
                jma->list[jma->s60] = jma->s20;
            }
            if (jma->s70 <= 127)
            {
                jma->s18 = 0;
                for( j = jma->s40 ; j<=jma->s38; j++)
                    jma->s18 = jma->s18 + jma->list[j];
            }
            jma->f60 = jma->s18 / (jma->s38 - jma->s40 + 1.0);
            if (jma->LP2 + 1 > 31)
                jma->LP2 = 31;
            else
                jma->LP2 = jma->LP2 + 1;
            if (jma->LP2 <= 30)
            {
                if (jma->f28 > 0.0)
                    jma->f18 = jma->f8;
                else
                    jma->f18 = jma->f8 - jma->f28 * jma->f90;
                if (jma->f48 < 0.0)
                    jma->f38 = jma->f8;
                else
                    jma->f38 = jma->f8 - jma->f48 * jma->f90;
                jma->vJMA = a_current;
                if (jma->LP2 != 30)
                    continue;
                if (jma->LP2==30)
                {
                    jma->fC0 = a_current;
                    if (ceil(jma->f78) >= 1)
                        jma->v4 = ceil(jma->f78);
                    else
                        jma->v4 = 1.0;

                    if(jma->v4 > 0)
                        jma->fE8 = floor(jma->v4);
                    else
                    {
                        if(jma->v4 < 0)
                            jma->fE8 = ceil (jma->v4);
                        else
                            jma->fE8 = 0.0;
                    }

                    if (floor(jma->f78) >= 1)
                        jma->v2 = floor(jma->f78);
                    else
                        jma->v2 = 1.0;

                    if(jma->v2>0)
                        jma->fE0 = floor(jma->v2);
                    else
                    {
                        if(jma->v2 < 0)
                            jma->fE0 = ceil (jma->v2);
                        else
                            jma->fE0 = 0.0;
                    }

                    if (jma->fE8 == jma->fE0)
                        jma->f68 = 1.0;
                    else
                    {
                        jma->v4 = jma->fE8 - jma->fE0; jma->f68 = (jma->f78 - jma->fE0) / jma->v4;
                    }
                    if (jma->fE0 <= 29)
                        jma->v5 = jma->fE0;
                    else
                        jma->v5 = 29;
                    if (jma->fE8 <= 29)
                        jma->v6 = jma->fE8;
                    else
                        jma->v6 = 29;
                    jma->fA8 = (a_current - jma->buffer[jma->LP1 - jma->v5]) * (1.0 - jma->f68) / jma->fE0 + (a_current - jma->buffer[jma->LP1 - jma->v6]) * jma->f68 / jma->fE8;
                }
            }
            else
            {
                if (jma->f98 >= pow(jma->fA0 / jma->f60, jma->f88))
                    jma->v1 = pow(jma->fA0/jma->f60, jma->f88);
                else
                    jma->v1 = jma->f98;
                if (jma->v1 < 1.0)
                    jma->v2 = 1.0;
                else
                {
                    if(jma->f98 >= pow(jma->fA0/jma->f60, jma->f88))
                        jma->v3 = pow(jma->fA0/jma->f60, jma->f88);
                    else
                        jma->v3 = jma->f98; jma->v2 = jma->v3;
                }
                jma->f58 = jma->v2;
                jma->f70 = pow(jma->f90, sqrt(jma->f58));
                if (jma->f28 > 0.0)
                    jma->f18 = jma->f8;
                else
                    jma->f18 = jma->f8 - jma->f28 * jma->f70;
                if (jma->f48 < 0.0)
                    jma->f38 = jma->f8;
                else jma->f38 = jma->f8 - jma->f48 * jma->f70;
            }
        }
        if (jma->LP2 > 30)
        {
            jma->f30 = pow(jma->Kg, jma->f58);
            jma->fC0 =(1.0 - jma->f30) * a_current + jma->f30 * jma->fC0;
            jma->fC8 =(a_current - jma->fC0) * (1.0 - jma->Kg) + jma->Kg * jma->fC8;
            jma->fD0 = jma->Pf * jma->fC8 + jma->fC0;
            jma->f20 = jma->f30 *(-2.0);
            jma->f40 = jma->f30 * jma->f30;
            jma->fB0 = jma->f20 + jma->f40 + 1.0;
            jma->fA8 = (jma->fD0 - jma->vJMA) * jma->fB0 + jma->f40 * jma->fA8;
            jma->vJMA = jma->vJMA + jma->fA8;
        }
    }

    if (jma->LP1 <= 30)
        jma->vJMA = 0.0;

    return jma->vJMA;
}


