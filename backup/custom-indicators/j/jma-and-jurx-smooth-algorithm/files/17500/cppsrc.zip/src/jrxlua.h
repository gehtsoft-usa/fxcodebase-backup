void lua_jrx_push(lua_State *L);
