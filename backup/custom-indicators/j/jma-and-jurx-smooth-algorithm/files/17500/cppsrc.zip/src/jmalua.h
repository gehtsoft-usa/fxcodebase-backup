void lua_jma_push(lua_State *L);
