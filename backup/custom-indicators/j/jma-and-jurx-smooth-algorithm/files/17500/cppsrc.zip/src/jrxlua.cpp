#include "stdafx.h"
#include "jrx.h"
#define INDICORE2_EXTKIT
#include "C:/Gehtsoft/IndicoreDev/include/indicore2.h"
#include "jrxlua.h"

#define jrx_cookie_id 0x60000001

JRX *lua_jrx_getinfo(lua_State *L, int index)
{
    return (JRX *)luax_getcookie(L, index, jrx_cookie_id);
}

int lua_jrx_gc(lua_State *L)
{
    JRX *info = *(JRX **)lua_touserdata(L, 1);
    if (info != 0)
        FreeJRX(info);
    return 0;
}

/* jrx:init(). */
int lua_jrx_init(lua_State *L)
{
    JRX *info = lua_jrx_getinfo(L, 1);
    if (info != 0)
        JRXInit(info);
    return 0;
}

/* jrx:prepare(phase, length). */
int lua_jrx_prepare(lua_State *L)
{
    JRX *info = lua_jrx_getinfo(L, 1);
    if (info != 0)
        JRXUpdateCoefficients(info, (int)lua_tonumber(L, 2));
    return 0;
}

/* jrx:save(). */
int lua_jrx_save(lua_State *L)
{
    JRX *info = lua_jrx_getinfo(L, 1);
    JRX *info1 = lua_jrx_getinfo(L, 2);
    if (info != 0 && info1 != 0)
        JRXStoreContext(info, info1);
    return 0;
}

/* jrx:restore(). */
int lua_jrx_restore(lua_State *L)
{
    JRX *info = lua_jrx_getinfo(L, 1);
    JRX *info1 = lua_jrx_getinfo(L, 2);
    if (info != 0 && info1 != 0)
        JRXRestoreContext(info, info1);
    return 0;
}

/* jrx:next(value). */
int lua_jrx_next(lua_State *L)
{
    JRX *info = lua_jrx_getinfo(L, 1);
    if (info != 0)
        lua_pushnumber(L, JRXSeries(info, lua_tonumber(L, 2)));
    else
        lua_pushnil(L);
    return 1;
}

void lua_jrx_push(lua_State *L)
{
    lua_newtable(L);
    JRX *jrx = AllocJRX();
    luax_setcookie(L, -1, jrx, jrx_cookie_id);
    lua_newuserdata(L, sizeof(JRX *));
    *(JRX **)(lua_touserdata(L, -1)) = jrx;
    if (luaL_newmetatable(L, "__jrx_metatableregc") != 0)
    {
        lua_pushcfunction(L, lua_jrx_gc);
        lua_setfield(L, -2, "__gc");
    }
    lua_setmetatable(L, -2);
    lua_setfield(L, -2, "rawdata");

    lua_pushcfunction(L, lua_jrx_init);
    lua_setfield(L, -2, "init");
    lua_pushcfunction(L, lua_jrx_prepare);
    lua_setfield(L, -2, "prepare");
    lua_pushcfunction(L, lua_jrx_save);
    lua_setfield(L, -2, "save");
    lua_pushcfunction(L, lua_jrx_restore);
    lua_setfield(L, -2, "restore");
    lua_pushcfunction(L, lua_jrx_next);
    lua_setfield(L, -2, "next");
    return ;
}




