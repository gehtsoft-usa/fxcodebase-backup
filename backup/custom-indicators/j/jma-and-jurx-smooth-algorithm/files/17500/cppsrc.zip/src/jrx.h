struct JRX;

struct JRX *AllocJRX();
void FreeJRX(struct JRX *jrx);
void JRXInit(struct JRX *jrx);
void JRXUpdateCoefficients(struct JRX *jrx, int length);
void JRXStoreContext(struct JRX *jrx, struct JRX *jrx1);
void JRXRestoreContext(struct JRX *jrx, struct JRX *jrx1);
double JRXSeries(struct JRX *jrx, double a_series);

