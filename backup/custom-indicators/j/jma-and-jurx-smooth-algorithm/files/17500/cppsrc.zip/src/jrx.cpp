#include "stdafx.h"
#include "jrx.h"
#include <math.h>

struct JRX {
    double f1, f2, f3, f4, f5, f6, Kg, Hg;
    double t1, t2, JurX;
};


struct JRX *AllocJRX()
{
    return new JRX;
}

void FreeJRX(struct JRX *jrx)
{
    delete jrx;
}

void JRXInit(struct JRX *jrx)
{
    jrx->f1 = 0;
    jrx->f2 = 0;
    jrx->f3 = 0;
    jrx->f4 = 0;
    jrx->f5 = 0;
    jrx->f6 = 0;
    jrx->Kg = 0;
    jrx->Hg = 0;
    jrx->t1 = 0;
    jrx->t2 = 0;
    jrx->JurX = 0;
}

void JRXUpdateCoefficients(struct JRX *jrx, int length)
{
    if (length < 1)
        length = 1;
    jrx->Kg= 3 / (length + 2.0);
    jrx->Hg = 1.0 - jrx->Kg;
    return ;
}

void JRXStoreContext(struct JRX *jrx, struct JRX *jrx1)
{
    memcpy(jrx1, jrx, sizeof(struct JRX));
}

void JRXRestoreContext(struct JRX *jrx, struct JRX *jrx1)
{
    memcpy(jrx, jrx1, sizeof(struct JRX));
}

double JRXSeries(struct JRX *jrx, double a_series)
{
    jrx->f1 = jrx->Hg * jrx->f1 + jrx->Kg * a_series;
    jrx->f2 = jrx->Kg * jrx->f1 + jrx->Hg * jrx->f2;
    jrx->t1 = 1.5 * jrx->f1 - 0.5 * jrx->f2;
    jrx->f3 = jrx->Hg * jrx->f3 + jrx->Kg * jrx->t1;
    jrx->f4 = jrx->Kg * jrx->f3 + jrx->Hg * jrx->f4;
    jrx->t2 = 1.5 * jrx->f3 - 0.5 * jrx->f4;
    jrx->f5 = jrx->Hg * jrx->f5 + jrx->Kg * jrx->t2;
    jrx->f6 = jrx->Kg * jrx->f5 + jrx->Hg * jrx->f6;
    jrx->JurX = 1.5 * jrx->f5 - 0.5 * jrx->f6;
    return jrx->JurX;
}

