#include "stdafx.h"
#include "jma.h"
#define INDICORE2_EXTKIT
#include "C:/Gehtsoft/IndicoreDev/include/indicore2.h"
#include "jmalua.h"

#define jma_cookie_id 0x60000001

JMA *lua_jma_getinfo(lua_State *L, int index)
{
    return (JMA *)luax_getcookie(L, index, jma_cookie_id);
}

int lua_jma_gc(lua_State *L)
{
    JMA *info = *(JMA **)lua_touserdata(L, 1);
    if (info != 0)
        FreeJMA(info);
    return 0;
}

/* jma:init(). */
int lua_jma_init(lua_State *L)
{
    JMA *info = lua_jma_getinfo(L, 1);
    if (info != 0)
        JJMAInit(info);
    return 0;
}

/* jma:prepare(phase, length). */
int lua_jma_prepare(lua_State *L)
{
    JMA *info = lua_jma_getinfo(L, 1);
    if (info != 0)
        JJMAUpdateCoefficients(info, (int)lua_tonumber(L, 2), (int)lua_tonumber(L, 3));
    return 0;
}

/* jma:save(). */
int lua_jma_save(lua_State *L)
{
    JMA *info = lua_jma_getinfo(L, 1);
    JMA *info1 = lua_jma_getinfo(L, 2);
    if (info != 0 && info1 != 0)
        JJMAStoreContext(info, info1);
    return 0;
}

/* jma:restore(). */
int lua_jma_restore(lua_State *L)
{
    JMA *info = lua_jma_getinfo(L, 1);
    JMA *info1 = lua_jma_getinfo(L, 2);
    if (info != 0 && info1 != 0)
        JJMARestoreContext(info, info1);
    return 0;
}

/* jma:next(value). */
int lua_jma_next(lua_State *L)
{
    JMA *info = lua_jma_getinfo(L, 1);
    if (info != 0)
        lua_pushnumber(L, JJMASeries(info, lua_tonumber(L, 2)));
    else
        lua_pushnil(L);
    return 1;
}

void lua_jma_push(lua_State *L)
{
    lua_newtable(L);
    JMA *jma = AllocJMA();
    luax_setcookie(L, -1, jma, jma_cookie_id);
    lua_newuserdata(L, sizeof(JMA *));
    *(JMA **)(lua_touserdata(L, -1)) = jma;
    if (luaL_newmetatable(L, "__jma_metatableregc") != 0)
    {
        lua_pushcfunction(L, lua_jma_gc);
        lua_setfield(L, -2, "__gc");
    }
    lua_setmetatable(L, -2);
    lua_setfield(L, -2, "rawdata");

    lua_pushcfunction(L, lua_jma_init);
    lua_setfield(L, -2, "init");
    lua_pushcfunction(L, lua_jma_prepare);
    lua_setfield(L, -2, "prepare");
    lua_pushcfunction(L, lua_jma_save);
    lua_setfield(L, -2, "save");
    lua_pushcfunction(L, lua_jma_restore);
    lua_setfield(L, -2, "restore");
    lua_pushcfunction(L, lua_jma_next);
    lua_setfield(L, -2, "next");
    return ;
}




