@echo off

IF /i "%1" == "debug" (
    set config=Debug
) ELSE (
    set config=Release
)

vcbuild jmalua.vcproj "%config%|Win32"

