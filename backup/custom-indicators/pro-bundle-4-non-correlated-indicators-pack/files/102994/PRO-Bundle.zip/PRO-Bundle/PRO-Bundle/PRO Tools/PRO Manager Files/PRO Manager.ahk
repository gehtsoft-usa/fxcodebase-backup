/*
ADJUST X,Y VALUES :
*/

X = 20
Y = 180

/*
ADJUST THE DELAY IF YOUR COMPUTER IS TOO SLOW :
*/

delay = 1

/*
CHANGE THE SHORTCUT KEYS REPLACING THEIR NAMES BEFORE THE :: (F15:: for exemple states for the F15key)
You have the list of all the customisable keys of the keyboard supported here : http://ahkscript.org/docs/KeyList.htm
*/

/*
BUY COMMAND
*/
PgUp::
SetMouseDelay, %delay%
CoordMode, Mouse, Screen
MouseGetPos, xpos, ypos
Click right %X%, %Y%
X += 40
Y += 70
Click %X%, %Y%
MouseMove, %xpos%, %ypos%
X -= 40
Y -= 70
return

/*
SELL COMMAND
*/
PgDn::
SetMouseDelay, %delay%
CoordMode, Mouse, Screen
MouseGetPos, xpos, ypos
Click right %X%, %Y%
X += 40
Y += 80
Click %X%, %Y%
MouseMove, %xpos%, %ypos%
X -= 40
Y -= 80
return

/*
CLOSE ALL LONG COMMAND
*/
^PgUp::
SetMouseDelay, %delay%
CoordMode, Mouse, Screen
MouseGetPos, xpos, ypos
Click right %X%, %Y%
X += 40
Y += 170
Click %X%, %Y%
MouseMove, %xpos%, %ypos%
X -= 40
Y -= 170
return

/*
CLOSE ALL SELL COMMAND
*/
^PgDn::
SetMouseDelay, %delay%
CoordMode, Mouse, Screen
MouseGetPos, xpos, ypos
Click right %X%, %Y%
X += 40
Y += 190
Click %X%, %Y%
MouseMove, %xpos%, %ypos%
X -= 40
Y -= 190
return

/*
CLOSE LAST ORDER COMMAND
*/
F13::
SetMouseDelay, %delay%
CoordMode, Mouse, Screen
MouseGetPos, xpos, ypos
Click right %X%, %Y%
X += 40
Y += 150
Click %X%, %Y%
MouseMove, %xpos%, %ypos%
X -= 40
Y -= 150
return

/*
SET STOP BREAKEVEN COMMAND
*/
F14::
SetMouseDelay, %delay%
CoordMode, Mouse, Screen
MouseGetPos, xpos, ypos
Click right %X%, %Y%
X += 40
Y += 210
Click %X%, %Y%
MouseMove, %xpos%, %ypos%
X -= 40
Y -= 210
return


/*
SPLIT COMMAND
*/
F15::
SetMouseDelay, %delay%
CoordMode, Mouse, Screen
MouseGetPos, xpos, ypos
Click right %X%, %Y%
X += 40
Y += 230
Click %X%, %Y%
MouseMove, %xpos%, %ypos%
X -= 40
Y -= 230
return


/*
SET PRESET1 COMMAND
*/
F16::
SetMouseDelay, %delay%
CoordMode, Mouse, Screen
MouseGetPos, xpos, ypos
Click right %X%, %Y%
X += 40
Y += 250
Click %X%, %Y%
MouseMove, %xpos%, %ypos%
X -= 40
Y -= 250
return

/*
SET PRESET2 COMMAND
*/
F17::
SetMouseDelay, %delay%
CoordMode, Mouse, Screen
MouseGetPos, xpos, ypos
Click right %X%, %Y%
X += 40
Y += 260
Click %X%, %Y%
MouseMove, %xpos%, %ypos%
X -= 40
Y -= 260
return

/*
SET PRESET3 COMMAND
*/
F18::
SetMouseDelay, %delay%
CoordMode, Mouse, Screen
MouseGetPos, xpos, ypos
Click right %X%, %Y%
X += 40
Y += 280
Click %X%, %Y%
MouseMove, %xpos%, %ypos%
X -= 40
Y -= 280
return

/*
SET NO PRESET COMMAND
*/
F19::
SetMouseDelay, %delay%
CoordMode, Mouse, Screen
MouseGetPos, xpos, ypos
Click right %X%, %Y%
X += 40
Y += 300
Click %X%, %Y%
MouseMove, %xpos%, %ypos%
X -= 40
Y -= 300
return




#Persistent

F1::
Suspend
TrayTip, AutoHotkey, Script ON/OFF switched, 20, 1
return
Aswitch = 1
Bswitch = 1

